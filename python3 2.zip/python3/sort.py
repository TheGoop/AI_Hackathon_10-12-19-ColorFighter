d = dict()
d={"1":20, "2":19, "3":40, "4":18}

vals = d.values()
vals.sort()

highestValue = max(s)

for k in d.keys():
	if d[k] == m:
		highestKey = k

print (highestKey)
